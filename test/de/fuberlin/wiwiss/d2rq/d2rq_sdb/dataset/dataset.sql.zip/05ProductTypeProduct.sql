CREATE TABLE "producttypeproduct" (
  "product" int not null,
  "productType" int not null,
  PRIMARY KEY ("product", "productType")
)
INSERT INTO "producttypeproduct" VALUES (1,5)INSERT INTO "producttypeproduct" VALUES (2,4)