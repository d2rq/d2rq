CREATE TABLE "vendor" (
  "nr" int,
  "label" varchar(100) default NULL,
  "comment" varchar(2000) default NULL,
  "homepage" varchar(100) default NULL,
  "country" char(2) default NULL,
  "publisher" int,
  "publishDate" date,
  primary key ("nr")
)
INSERT INTO "vendor" VALUES (1,'reexhibit wrang','linoleums cowsheds preconceive undergrounder nosier sawhorse coerces assn turgidities venins obliged homogenize componential redemonstrates dewberries pearlers triplicates planked goddaughters largeness citator palpal thoroughly enactive swimmiest syrups chanceman ventrals phlegmy','http://www.vendor1.com/','GB',1,'2008-05-06')
