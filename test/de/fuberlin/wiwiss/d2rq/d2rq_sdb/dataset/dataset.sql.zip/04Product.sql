CREATE TABLE "product" (
  "nr" int,
  "label" varchar(100) default NULL,
  "comment" varchar(2000) default NULL,
  "producer" int default NULL,
  "propertyNum1" int default NULL,
  "propertyNum2" int default NULL,
  "propertyNum3" int default NULL,
  "propertyNum4" int default NULL,
  "propertyNum5" int default NULL,
  "propertyNum6" int default NULL,
  "propertyTex1" varchar(200) default NULL,
  "propertyTex2" varchar(200) default NULL,
  "propertyTex3" varchar(200) default NULL,
  "propertyTex4" varchar(200) default NULL,
  "propertyTex5" varchar(200) default NULL,
  "propertyTex6" varchar(200) default NULL,
  "publisher" int default NULL,
  "publishDate" date default NULL,
  primary key ("nr")
)
INSERT INTO "product" VALUES (1,'manner gatemen','lordlings dialyzed hoardings palmitate resisters redesigned trowing fledging disinters occasionally refry objective comedown senders attendance calculous redux zed bidets subacute swinks berhymed pumping overassured outrush corteges chitters civilest chiffonniers kimonos protects epizootic centimos dismast boomage issues aggrieves sociably ammoniacs polliwogs labyrinths infatuates whiteout dissentients newmown flunkey titillated caduceus rediscovered breaststrokes schillings endorsement cheerleaders nonconcurrent intoned outpaces inkle superpowers habaneras subsoils paramours laughed guzzling jillion psychotherapists substantiation nonuple deluded snowmelt interlards overrefinement annoyed stuntedness calcimining stereophonically recommendation embezzler reconviction misproportions discountenances callings defacers crummiest triglyceride decentralizations impacting promulgations bibliotherapy murexes professorships locomotes durning lyncher spoonier abhorrence assize',1,
483,1432,348,null,null,75,'goglets distracts universally trashily enervator','naughtiness illuminating careerers','computerese brakeless mesozoa lineate fulminant batholiths mohawks',null,'exhalation paraguayan alcaldes foulings','primordially almightily placed',















1,'2001-08-15')
INSERT INTO "product" VALUES (2,'coterie ahchoo','flukey improvises pommelled sententious bookmark rashers truces mordanted shunter praxeological causable compassed decertified transubstantiation automatize boxful befouling tragedienne visiting alliums triangulates hounders compressively camphorates mammons armories scrapes hanger nucleation loftless refractoriness nonhabitual paperer aridness jingliest sportswriters gained efficiently marshals tomogram tambura pureeing doughty compromised antineutrinos revertible picadors oddballs hominies drek irradiations fearlessness cortin hussy museful pupfish bulletproofing geminates nacre subsistence presifted abhors whereat wanes mooing refused biodegradability oghamic stouter venosities recopying supplantation buxomly foregoers pathologist welches comicality manifestos untangles mongols sluices demits inventers entitled taxability fancifulness claimed gastroenterology geotropically glenwood alack autochthonous nabob preempts alternativeness xviii fruiter deist electorally cooker voce abbeys composts jugsful glowing',1,
1041,74,706,null,null,null,'basset worshipfully rebait bushwhacker implorer','jackknifing paraguayan enrolls blazonry dendrological pavilioned cully epistles foreshorten couth usurps legibilities yammered somnolently scalded','decoct practitioners infolds levered quartan calcined untransferable auditoria charred payment',null,null,null,






















1,'2002-08-26')
