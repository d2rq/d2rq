CREATE TABLE "person" (
  "nr" int,
  "name" varchar(30) default NULL,
  "mbox_sha1sum" char(40) default NULL,
  "country" char(2) default NULL,
  "publisher" int,
  "publishDate" date,
  primary key ("nr")
)
INSERT INTO "person" VALUES (1,'Ruggiero-Delane','ce2fd8b0d636e2836c5eeff34088453c375a132','JP',1,'2008-09-06')
