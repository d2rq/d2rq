CREATE TABLE "producer" (
  "nr" int,
  "label" varchar(100) default NULL,
  "comment" varchar(2000) default NULL,
  "homepage" varchar(100) default NULL,
  "country" char(2) default NULL,
  "publisher" int,
  "publishDate" date,
  primary key ("nr")
)
INSERT INTO "producer" VALUES (1,'enzymologist neb falsehoods','smashes leavening beauticians novitiates peaks nonhistoric fluorinations seductresses promotions corresponding denuder wispier laboriousness mechanisms skepsis tulips barstools demobs bandmasters pallbearer','http://www.Producer1.com/','DE',1,'2003-06-15')
