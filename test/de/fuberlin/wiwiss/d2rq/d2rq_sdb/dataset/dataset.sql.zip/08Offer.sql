CREATE TABLE "offer" (
  "nr" int,
  "product" int,
  "producer" int,
  "vendor" int,
  "price" double default null,
  "validFrom" datetime default null,
  "validTo" datetime default null,
  "deliveryDays" integer default null,
  "offerWebpage" varchar(100) default NULL,
  "publisher" int,
  "publishDate" date,
  primary key ("nr")
)
INSERT INTO "offer" VALUES (1,2,1,1,5728.1,'2008-02-10','2008-05-21',3,'http://www4.wiwiss.fu-berlin.de/bizer/bsbm/v01/instances/dataFromVendor1/Offer1/',1,'2008-04-10')
INSERT INTO "offer" VALUES (2,2,1,1,8672.7,'2008-02-21','2008-04-21',3,'http://www4.wiwiss.fu-berlin.de/bizer/bsbm/v01/instances/dataFromVendor1/Offer2/',1,'2008-04-02')
INSERT INTO "offer" VALUES (3,1,1,1,6768.1,'2008-03-26','2008-07-17',2,'http://www4.wiwiss.fu-berlin.de/bizer/bsbm/v01/instances/dataFromVendor1/Offer3/',1,'2008-05-11')
INSERT INTO "offer" VALUES (4,2,1,1,5159.5,'2008-01-06','2008-06-25',5,'http://www4.wiwiss.fu-berlin.de/bizer/bsbm/v01/instances/dataFromVendor1/Offer4/',1,'2008-03-28')
INSERT INTO "offer" VALUES (5,2,1,1,6935.5,'2008-04-01','2008-06-21',5,'http://www4.wiwiss.fu-berlin.de/bizer/bsbm/v01/instances/dataFromVendor1/Offer5/',1,'2008-06-04')
INSERT INTO "offer" VALUES (6,1,1,1,7284.0,'2008-05-05','2008-08-15',3,'http://www4.wiwiss.fu-berlin.de/bizer/bsbm/v01/instances/dataFromVendor1/Offer6/',1,'2008-06-16')
INSERT INTO "offer" VALUES (7,2,1,1,6322.7,'2008-03-24','2008-07-02',6,'http://www4.wiwiss.fu-berlin.de/bizer/bsbm/v01/instances/dataFromVendor1/Offer7/',1,'2008-05-09')
INSERT INTO "offer" VALUES (8,2,1,1,3490.6,'2008-04-10','2008-05-12',2,'http://www4.wiwiss.fu-berlin.de/bizer/bsbm/v01/instances/dataFromVendor1/Offer8/',1,'2008-05-04')
INSERT INTO "offer" VALUES (9,1,1,1,8905.7,'2008-04-08','2008-08-13',3,'http://www4.wiwiss.fu-berlin.de/bizer/bsbm/v01/instances/dataFromVendor1/Offer9/',1,'2008-05-21')
INSERT INTO "offer" VALUES (10,1,1,1,869.7,'2008-05-10','2008-08-07',4,'http://www4.wiwiss.fu-berlin.de/bizer/bsbm/v01/instances/dataFromVendor1/Offer10/',1,'2008-05-17')
INSERT INTO "offer" VALUES (11,2,1,1,8822.0,'2008-03-10','2008-05-30',4,'http://www4.wiwiss.fu-berlin.de/bizer/bsbm/v01/instances/dataFromVendor1/Offer11/',1,'2008-04-23')
INSERT INTO "offer" VALUES (12,2,1,1,6709.7,'2008-01-13','2008-05-28',2,'http://www4.wiwiss.fu-berlin.de/bizer/bsbm/v01/instances/dataFromVendor1/Offer12/',1,'2008-03-19')
INSERT INTO "offer" VALUES (13,1,1,1,6401.0,'2008-06-03','2008-08-30',5,'http://www4.wiwiss.fu-berlin.de/bizer/bsbm/v01/instances/dataFromVendor1/Offer13/',1,'2008-06-04')
INSERT INTO "offer" VALUES (14,2,1,1,8437.6,'2008-03-20','2008-05-30',2,'http://www4.wiwiss.fu-berlin.de/bizer/bsbm/v01/instances/dataFromVendor1/Offer14/',1,'2008-04-03')
INSERT INTO "offer" VALUES (15,2,1,1,254.3,'2008-03-24','2008-05-20',3,'http://www4.wiwiss.fu-berlin.de/bizer/bsbm/v01/instances/dataFromVendor1/Offer15/',1,'2008-03-25')
INSERT INTO "offer" VALUES (16,2,1,1,7723.7,'2008-04-15','2008-08-22',2,'http://www4.wiwiss.fu-berlin.de/bizer/bsbm/v01/instances/dataFromVendor1/Offer16/',1,'2008-06-15')
INSERT INTO "offer" VALUES (17,1,1,1,6734.3,'2008-04-12','2008-07-30',4,'http://www4.wiwiss.fu-berlin.de/bizer/bsbm/v01/instances/dataFromVendor1/Offer17/',1,'2008-05-06')
INSERT INTO "offer" VALUES (18,1,1,1,7927.9,'2008-03-16','2008-04-02',2,'http://www4.wiwiss.fu-berlin.de/bizer/bsbm/v01/instances/dataFromVendor1/Offer18/',1,'2008-03-20')
INSERT INTO "offer" VALUES (19,2,1,1,2255.4,'2008-03-18','2008-07-08',2,'http://www4.wiwiss.fu-berlin.de/bizer/bsbm/v01/instances/dataFromVendor1/Offer19/',1,'2008-04-24')
INSERT INTO "offer" VALUES (20,1,1,1,1388.8,'2008-04-03','2008-06-14',3,'http://www4.wiwiss.fu-berlin.de/bizer/bsbm/v01/instances/dataFromVendor1/Offer20/',1,'2008-04-23')
INSERT INTO "offer" VALUES (21,2,1,1,6986.7,'2008-05-12','2008-06-26',5,'http://www4.wiwiss.fu-berlin.de/bizer/bsbm/v01/instances/dataFromVendor1/Offer21/',1,'2008-05-16')
INSERT INTO "offer" VALUES (22,1,1,1,4507.8,'2008-05-16','2008-06-21',5,'http://www4.wiwiss.fu-berlin.de/bizer/bsbm/v01/instances/dataFromVendor1/Offer22/',1,'2008-05-29')
INSERT INTO "offer" VALUES (23,1,1,1,923.8,'2008-03-12','2008-06-13',2,'http://www4.wiwiss.fu-berlin.de/bizer/bsbm/v01/instances/dataFromVendor1/Offer23/',1,'2008-06-06')
INSERT INTO "offer" VALUES (24,1,1,1,4193.0,'2008-03-31','2008-06-14',5,'http://www4.wiwiss.fu-berlin.de/bizer/bsbm/v01/instances/dataFromVendor1/Offer24/',1,'2008-04-25')
INSERT INTO "offer" VALUES (25,1,1,1,4326.2,'2008-05-08','2008-08-15',2,'http://www4.wiwiss.fu-berlin.de/bizer/bsbm/v01/instances/dataFromVendor1/Offer25/',1,'2008-05-25')
INSERT INTO "offer" VALUES (26,2,1,1,8640.3,'2008-02-20','2008-04-17',3,'http://www4.wiwiss.fu-berlin.de/bizer/bsbm/v01/instances/dataFromVendor1/Offer26/',1,'2008-04-05')
INSERT INTO "offer" VALUES (27,2,1,1,5193.1,'2008-05-05','2008-07-08',2,'http://www4.wiwiss.fu-berlin.de/bizer/bsbm/v01/instances/dataFromVendor1/Offer27/',1,'2008-06-10')
INSERT INTO "offer" VALUES (28,1,1,1,9267.2,'2008-03-10','2008-07-20',2,'http://www4.wiwiss.fu-berlin.de/bizer/bsbm/v01/instances/dataFromVendor1/Offer28/',1,'2008-06-03')
INSERT INTO "offer" VALUES (29,2,1,1,5578.3,'2008-03-07','2008-05-03',3,'http://www4.wiwiss.fu-berlin.de/bizer/bsbm/v01/instances/dataFromVendor1/Offer29/',1,'2008-04-25')
INSERT INTO "offer" VALUES (30,2,1,1,8144.2,'2008-05-19','2008-08-18',5,'http://www4.wiwiss.fu-berlin.de/bizer/bsbm/v01/instances/dataFromVendor1/Offer30/',1,'2008-06-12')
INSERT INTO "offer" VALUES (31,2,1,1,7259.1,'2008-01-21','2008-04-02',3,'http://www4.wiwiss.fu-berlin.de/bizer/bsbm/v01/instances/dataFromVendor1/Offer31/',1,'2008-03-25')
INSERT INTO "offer" VALUES (32,1,1,1,7166.8,'2008-04-03','2008-05-13',5,'http://www4.wiwiss.fu-berlin.de/bizer/bsbm/v01/instances/dataFromVendor1/Offer32/',1,'2008-05-02')
INSERT INTO "offer" VALUES (33,1,1,1,4696.7,'2008-03-26','2008-07-17',3,'http://www4.wiwiss.fu-berlin.de/bizer/bsbm/v01/instances/dataFromVendor1/Offer33/',1,'2008-04-23')
INSERT INTO "offer" VALUES (34,1,1,1,967.9,'2008-01-28','2008-05-07',3,'http://www4.wiwiss.fu-berlin.de/bizer/bsbm/v01/instances/dataFromVendor1/Offer34/',1,'2008-04-20')
INSERT INTO "offer" VALUES (35,1,1,1,9860.9,'2008-02-15','2008-03-31',3,'http://www4.wiwiss.fu-berlin.de/bizer/bsbm/v01/instances/dataFromVendor1/Offer35/',1,'2008-03-21')
INSERT INTO "offer" VALUES (36,2,1,1,5466.0,'2008-03-22','2008-04-19',1,'http://www4.wiwiss.fu-berlin.de/bizer/bsbm/v01/instances/dataFromVendor1/Offer36/',1,'2008-03-28')
INSERT INTO "offer" VALUES (37,2,1,1,9225.9,'2008-03-26','2008-06-17',5,'http://www4.wiwiss.fu-berlin.de/bizer/bsbm/v01/instances/dataFromVendor1/Offer37/',1,'2008-06-01')
INSERT INTO "offer" VALUES (38,1,1,1,7977.4,'2008-02-18','2008-06-15',5,'http://www4.wiwiss.fu-berlin.de/bizer/bsbm/v01/instances/dataFromVendor1/Offer38/',1,'2008-04-16')
INSERT INTO "offer" VALUES (39,1,1,1,7855.1,'2008-03-21','2008-07-21',3,'http://www4.wiwiss.fu-berlin.de/bizer/bsbm/v01/instances/dataFromVendor1/Offer39/',1,'2008-05-15')
INSERT INTO "offer" VALUES (40,2,1,1,2693.7,'2008-02-25','2008-07-10',2,'http://www4.wiwiss.fu-berlin.de/bizer/bsbm/v01/instances/dataFromVendor1/Offer40/',1,'2008-05-21')
